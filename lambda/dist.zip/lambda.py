def my_handler(event, context):
    return { "result": event["n"] * 2 }
